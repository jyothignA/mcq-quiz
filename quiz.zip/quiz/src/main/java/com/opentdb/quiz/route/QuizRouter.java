package com.opentdb.quiz.route;

import static org.springframework.web.reactive.function.server.RequestPredicates.GET;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.opentdb.quiz.handler.QuizHandler;

@Configuration
public class QuizRouter {

	@Bean
	public RouterFunction<ServerResponse> fetchQuiz(QuizHandler quizHandler) {
		return RouterFunctions.route(GET("/coding/exercise/quiz"), quizHandler::fetchQuiz);
	}
}
