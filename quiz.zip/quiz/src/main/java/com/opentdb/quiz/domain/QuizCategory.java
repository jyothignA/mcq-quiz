package com.opentdb.quiz.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class QuizCategory {
	
	@JsonProperty("category")
	private String category;
	
	@JsonProperty("results")
	private List<Quiz> quizs;
	
	public QuizCategory() {
		this.quizs = new ArrayList<Quiz>();
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public List<Quiz> getQuizs() {
		return quizs;
	}

	public void setQuizs(List<Quiz> quizs) {
		this.quizs = quizs;
	}
	
	public void addQuiz(Quiz quiz) {
		if (quiz!=null) {
			this.quizs.add(quiz);
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof QuizCategory)) {
			return false;
		}
		QuizCategory quizCategory = (QuizCategory) obj;
		return Objects.equals(quizCategory.category, this.category);
	}
}
