package com.opentdb.quiz.service;

import org.springframework.stereotype.Component;

import com.opentdb.quiz.domain.QuizQuestions;
import com.opentdb.quiz.domain.QuizResponse;
import com.opentdb.quiz.repository.QuizRepository;
import com.opentdb.quiz.util.QuizUtils;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class QuizServiceImpl implements QuizService {

	private QuizRepository quizRepository;

	public QuizServiceImpl(QuizRepository quizRepository) {
		this.quizRepository = quizRepository;
	}

	public Flux<QuizResponse> fetchQuizQuestion() {
		Mono<QuizQuestions> quizQuestions11 = this.quizRepository.fetchQuestionByAmountAndCategory(5, 11);
		Mono<QuizQuestions> quizQuestions12 = this.quizRepository.fetchQuestionByAmountAndCategory(5, 12);
		return quizQuestions11.zipWith(quizQuestions12).flatMapMany(quizQuestion -> {
			QuizResponse quizResponse = new QuizResponse();
			QuizUtils.addQuizToQuizCategory(quizResponse, quizQuestion.getT1());
			QuizUtils.addQuizToQuizCategory(quizResponse, quizQuestion.getT2());
			return Mono.just(quizResponse);
		});
	}


}
