package com.opentdb.quiz.domain;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Quiz {
	
	@JsonProperty("type")
	private String type;
	
	@JsonProperty("difficulty")
	private String difficulty;
	
	@JsonProperty("question")
	private String question;
	
	@JsonProperty("correct_answer")
	private String answer;
	
	@JsonProperty("all_answers")
	private List<String> options;
	
	public Quiz() {
		this.options = new ArrayList<String>();
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public List<String> getOptions() {
		return options;
	}

	public void setOptions(List<String> options) {
		this.options = options;
	}
	
	public void addOption(String option) {
		if (option!=null) {
			this.options.add(option);
		}
	}
}
