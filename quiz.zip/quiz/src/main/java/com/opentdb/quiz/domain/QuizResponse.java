package com.opentdb.quiz.domain;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class QuizResponse {

	@JsonProperty("quiz")
	private List<QuizCategory> quizCategory;

	public QuizResponse() {
		this.quizCategory = new ArrayList<QuizCategory>();
	}

	public List<QuizCategory> getQuizCategory() {
		return quizCategory;
	}

	public void setQuizCategory(List<QuizCategory> quizCategory) {
		this.quizCategory = quizCategory;
	}

	public void addQuizCategory(QuizCategory quizCategory) {
		if (quizCategory != null) {
			this.quizCategory.add(quizCategory);
		}
	}
}
