package com.opentdb.quiz.convert;

import org.springframework.core.convert.converter.Converter;

import com.opentdb.quiz.domain.QuizCategory;
import com.opentdb.quiz.domain.QuizQuestion;

public class QuizQuestionToQuizCategoryConvert implements Converter<QuizQuestion, QuizCategory> {

	@Override
	public QuizCategory convert(QuizQuestion quizQuestion) {
		if(quizQuestion==null) {
			return null;
		}
		QuizQuestionToQuizConvert questionToQuizConvert = new QuizQuestionToQuizConvert();
		QuizCategory quizCategory = new QuizCategory();
		quizCategory.setCategory(quizQuestion.getCategory());
		quizCategory.addQuiz(questionToQuizConvert.convert(quizQuestion));
		return quizCategory;
	}

}
