package com.opentdb.quiz.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class QuizQuestions {
	@JsonProperty("response_code")
	private String responseCode;
	@JsonProperty("results")
	private List<QuizQuestion> quizQuestions;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public List<QuizQuestion> getQuizQuestions() {
		return quizQuestions;
	}

	public void setQuizQuestions(List<QuizQuestion> quizQuestions) {
		this.quizQuestions = quizQuestions;
	}

}
