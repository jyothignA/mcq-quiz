package com.opentdb.quiz.util;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.opentdb.quiz.convert.QuizQuestionToQuizCategoryConvert;
import com.opentdb.quiz.domain.QuizCategory;
import com.opentdb.quiz.domain.QuizQuestions;
import com.opentdb.quiz.domain.QuizResponse;

public abstract class QuizUtils {

	public static QuizResponse addQuizToQuizCategory(QuizResponse quizResponse, QuizQuestions quizQuestions) {
		if (quizQuestions == null) {
			return quizResponse;
		}
		QuizResponse response = quizResponse;
		QuizQuestionToQuizCategoryConvert quizCategoryConvert = new QuizQuestionToQuizCategoryConvert();
		if (quizQuestions.getQuizQuestions() != null && !CollectionUtils.isEmpty(quizQuestions.getQuizQuestions())) {
			quizQuestions.getQuizQuestions().stream()
											.map(question -> quizCategoryConvert.convert(question))
											.map(category -> quizResponse(response, category))
											.collect(Collectors.toList());
		}
		return response;
	}

	public static QuizResponse quizResponse(QuizResponse quizResponse, QuizCategory quizCategory) {
		if (quizCategory == null) {
			return null;
		}
		List<QuizCategory> quizCategories = quizResponse.getQuizCategory();
		int index = quizCategories.indexOf(quizCategory);
		if (index < 0) {
			quizCategories.add(quizCategory);
		} else {
			QuizCategory category = quizCategories.get(index);
			quizCategory.getQuizs()
						.forEach(quiz -> category.addQuiz(quiz));
		}
		return quizResponse;
	}
}
