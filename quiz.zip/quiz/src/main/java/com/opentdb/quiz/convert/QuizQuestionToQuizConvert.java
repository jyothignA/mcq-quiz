package com.opentdb.quiz.convert;

import org.springframework.core.convert.converter.Converter;

import com.opentdb.quiz.domain.Quiz;
import com.opentdb.quiz.domain.QuizQuestion;

public class QuizQuestionToQuizConvert implements Converter<QuizQuestion, Quiz> {

	@Override
	public Quiz convert(QuizQuestion quizQuestion) {
		if (quizQuestion == null) {
			return null;
		}
		Quiz quiz = new Quiz();
		quiz.setDifficulty(quizQuestion.getDifficulty());
		quiz.setAnswer(quizQuestion.getAnswer());
		quiz.setType(quizQuestion.getType());
		quiz.setQuestion(quizQuestion.getQuestion());
		quiz.addOption(quizQuestion.getAnswer());
		quizQuestion.getIncorrectAnswer().forEach(option -> quiz.addOption(option));
		return quiz;
	}

}
