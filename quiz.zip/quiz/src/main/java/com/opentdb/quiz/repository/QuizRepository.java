package com.opentdb.quiz.repository;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.opentdb.quiz.domain.QuizQuestions;

import reactor.core.publisher.Mono;

@Component
public class QuizRepository {
	
	private String quizUri;
	
	public QuizRepository(
			@Value("${quiz.question.service.base_url:https://opentdb.com/api.php}") 
			String quizUri
	) {
		this.quizUri = quizUri;
	}
	
	public Mono<QuizQuestions> fetchQuestionByAmountAndCategory(Integer amount, Integer category) {
		return WebClient.create(quizUri)
						.get()
						.uri(uriBuilder -> uriBuilder.queryParam("amount", amount)
													 .queryParam("category", category)
													 .build(amount, category))
						.exchangeToMono(response -> {
							if (HttpStatus.OK.equals(response.statusCode())) {
								return response.bodyToMono(QuizQuestions.class);
							}
							return Mono.empty();
						});
	}
}
