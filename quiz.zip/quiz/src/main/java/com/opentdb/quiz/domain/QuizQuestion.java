package com.opentdb.quiz.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class QuizQuestion {
	
	@JsonProperty("category")
	private String category;
	
	@JsonProperty("type")
	private String type;
	
	@JsonProperty("difficulty")
	private String difficulty;
	
	@JsonProperty("question")
	private String question;
	
	@JsonProperty("correct_answer")
	private String answer;
	
	@JsonProperty("incorrect_answers")
	private List<String> incorrectAnswer;
	
	public String getCategory() {
		return category;
	}
	
	public void setCategory(String category) {
		this.category = category;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getDifficulty() {
		return difficulty;
	}
	
	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}
	
	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}
	
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	public List<String> getIncorrectAnswer() {
		return incorrectAnswer;
	}
	
	public void setIncorrectAnswer(List<String> incorrectAnswer) {
		this.incorrectAnswer = incorrectAnswer;
	}
}
