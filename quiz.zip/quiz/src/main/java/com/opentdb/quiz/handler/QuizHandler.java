package com.opentdb.quiz.handler;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.opentdb.quiz.domain.QuizQuestions;
import com.opentdb.quiz.service.QuizService;

import reactor.core.publisher.Mono;

@Component
public class QuizHandler {
	
	private QuizService quizService;
	
	public QuizHandler(QuizService quizService) {
		this.quizService = quizService;
	}

	public Mono<ServerResponse> fetchQuiz(ServerRequest request) {
		return ServerResponse.ok()
							 .contentType(MediaType.APPLICATION_JSON)
							 .body(BodyInserters.fromProducer(quizService.fetchQuizQuestion(), QuizQuestions.class));
	}

}
