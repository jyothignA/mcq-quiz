package com.opentdb.quiz.service;

import com.opentdb.quiz.domain.QuizResponse;

import reactor.core.publisher.Flux;

public interface QuizService {

	public Flux<QuizResponse> fetchQuizQuestion();

}
